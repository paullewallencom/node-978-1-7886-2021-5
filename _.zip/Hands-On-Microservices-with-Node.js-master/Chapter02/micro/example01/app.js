module.exports = (req, res) => {
	res.end("Hello World");
};
